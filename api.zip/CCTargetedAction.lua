-- @module CCTargetedAction

-----------------------
-- @function [parent=#CCTargetedAction] create
-- @param  pTarget
-- @param  pAction

-----------------------
return nil
