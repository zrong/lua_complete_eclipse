-- @module CCAccelAmplitude

-----------------------
-- @function [parent=#CCAccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
