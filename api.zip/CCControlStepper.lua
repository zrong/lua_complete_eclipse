-- @module CCControlStepper

-----------------------
-- @function [parent=#CCControlStepper] create
-- @param  minusSprite
-- @param  plusSprite

-----------------------
-- @function [parent=#CCControlStepper] setWraps
-- @param  self
-- @param  wraps

-----------------------
-- @function [parent=#CCControlStepper] setMinimumValue
-- @param  self
-- @param  minimumValue

-----------------------
-- @function [parent=#CCControlStepper] setMaximumValue
-- @param  self
-- @param  maximumValue

-----------------------
-- @function [parent=#CCControlStepper] setValue
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCControlStepper] getValue
-- @param  self

-----------------------
-- @function [parent=#CCControlStepper] setStepValue
-- @param  self
-- @param  stepValue

-----------------------
-- @function [parent=#CCControlStepper] setValueWithSendingEvent
-- @param  self
-- @param  value
-- @param  send

-----------------------
-- @function [parent=#CCControlStepper] isContinuous
-- @param  self

-----------------------
return nil
