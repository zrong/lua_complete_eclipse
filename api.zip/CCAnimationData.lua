-- @module CCAnimationData

-----------------------
-- @function [parent=#CCAnimationData] addMovement
-- @param  self
-- @param  movData

-----------------------
-- @function [parent=#CCAnimationData] getMovementCount
-- @param  self

-----------------------
return nil
