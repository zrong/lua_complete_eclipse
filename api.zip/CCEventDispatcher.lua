-- @module CCEventDispatcher

-----------------------
-- @function [parent=#CCEventDispatcher] addScriptEventListener
-- @param  self
-- @param  event
-- @param  callback

-----------------------
-- @function [parent=#CCEventDispatcher] removeScriptEventListener
-- @param  self
-- @param  event
-- @param  handle

-----------------------
-- @function [parent=#CCEventDispatcher] removeAllScriptEventListenersForEvent
-- @param  self
-- @param  event

-----------------------
-- @function [parent=#CCEventDispatcher] removeAllScriptEventListeners
-- @param  self

-----------------------
-- @function [parent=#CCEventDispatcher] hasScriptEventListener
-- @param  self
-- @param  event

-----------------------
return nil
