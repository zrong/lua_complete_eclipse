-- @module CCTransitionFadeTR

-----------------------
-- @function [parent=#CCTransitionFadeTR] create
-- @param  t
-- @param  scene

-----------------------
return nil
