-- @module CCTurnOffTiles

-----------------------
-- @function [parent=#CCTurnOffTiles] create
-- @param  duration
-- @param  gridSize
-- @param  seed

-----------------------
-- @function [parent=#CCTurnOffTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
