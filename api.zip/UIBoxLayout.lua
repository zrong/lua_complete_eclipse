-- @module UIBoxLayout

-----------------------
-- @function [parent=#UIBoxLayout] ctor
-- @param  self
-- @param  direction
-- @param  name

-----------------------
-- @function [parent=#UIBoxLayout] getDirection
-- @param  self

-----------------------
-- @function [parent=#UIBoxLayout] setDirection
-- @param  self
-- @param  direction

-----------------------
-- @function [parent=#UIBoxLayout] apply
-- @param  self
-- @param  container

-----------------------
return nil
