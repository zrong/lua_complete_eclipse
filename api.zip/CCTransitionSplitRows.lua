-- @module CCTransitionSplitRows

-----------------------
-- @function [parent=#CCTransitionSplitRows] create
-- @param  t
-- @param  scene

-----------------------
return nil
