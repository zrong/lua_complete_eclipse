-- @module CCImage

-----------------------
return nil
