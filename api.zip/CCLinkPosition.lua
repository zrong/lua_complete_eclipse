-- @module CCLinkPosition

-----------------------
-- @function [parent=#CCLinkPosition] create
-- @param  pFollowedNode

-----------------------
return nil
