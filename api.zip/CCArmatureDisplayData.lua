-- @module CCArmatureDisplayData

-----------------------
-- @function [parent=#CCArmatureDisplayData] setParam
-- @param  self
-- @param  displayName

-----------------------
-- @function [parent=#CCArmatureDisplayData] copy
-- @param  self
-- @param  displayData

-----------------------
return nil
