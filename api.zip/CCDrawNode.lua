-- @module CCDrawNode

-----------------------
-- @function [parent=#CCDrawNode] create

-----------------------
-- @function [parent=#CCDrawNode] drawDot
-- @param  self
-- @param  pos
-- @param  radius
-- @param  color

-----------------------
-- @function [parent=#CCDrawNode] drawSegment
-- @param  self
-- @param  from
-- @param  to
-- @param  radius
-- @param  color

-----------------------
-- @function [parent=#CCDrawNode] drawPolygon
-- @param  self
-- @param  verts
-- @param  fillColor
-- @param  borderWidth
-- @param  borderColor

-----------------------
-- @function [parent=#CCDrawNode] clear
-- @param  self

-----------------------
-- @function [parent=#CCDrawNode] getBlendFunc
-- @param  self

-----------------------
-- @function [parent=#CCDrawNode] setBlendFunc
-- @param  self
-- @param  blendFunc

-----------------------
return nil
