-- @module CCAnimate

-----------------------
-- @function [parent=#CCAnimate] create
-- @param  pAnimation

-----------------------
return nil
