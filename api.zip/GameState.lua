-- @module GameState

-----------------------
-- @field [parent=#GameState] ERROR_INVALID_FILE_CONTENTS

-----------------------
-- @field [parent=#GameState] ERROR_HASH_MISS_MATCH

-----------------------
-- @field [parent=#GameState] ERROR_STATE_FILE_NOT_FOUND

-----------------------
-- @function [parent=#GameState] init
-- @param  eventListener_
-- @param  stateFilename_
-- @param  secretKey_

-----------------------
-- @function [parent=#GameState] load

-----------------------
-- @function [parent=#GameState] save
-- @param  newValues

-----------------------
-- @function [parent=#GameState] getGameStatePath

-----------------------
return nil
