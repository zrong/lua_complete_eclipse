-- @module ccBezierConfig

-----------------------
-- @function [parent=#ccBezierConfig] ccBezierConfig
-- @param  self

-----------------------
return nil
