-- @module CCControlPotentiometer

-----------------------
-- @function [parent=#CCControlPotentiometer] create
-- @param  backgroundFile
-- @param  progressFile
-- @param  thumbFile

-----------------------
-- @function [parent=#CCControlPotentiometer] setValue
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCControlPotentiometer] getValue
-- @param  self

-----------------------
-- @function [parent=#CCControlPotentiometer] setMinimumValue
-- @param  self
-- @param  minimumValue

-----------------------
-- @function [parent=#CCControlPotentiometer] getMinimumValue
-- @param  self

-----------------------
-- @function [parent=#CCControlPotentiometer] setMaximumValue
-- @param  self
-- @param  maximumValue

-----------------------
-- @function [parent=#CCControlPotentiometer] getMaximumValue
-- @param  self

-----------------------
return nil
