-- @module CCTransitionFade

-----------------------
-- @function [parent=#CCTransitionFade] ccc3
-- @param  self
-- @param  255
-- @param  0
-- @param  0

-----------------------
-- @function [parent=#CCTransitionFade] create
-- @param  duration
-- @param  scene
-- @param  color

-----------------------
-- @function [parent=#CCTransitionFade] create
-- @param  duration
-- @param  scene

-----------------------
return nil
