-- @module CCFadeIn

-----------------------
-- @function [parent=#CCFadeIn] create
-- @param  d

-----------------------
return nil
