-- @module CCEGLViewProtocol

-----------------------
-- @function [parent=#CCEGLViewProtocol] getFrameSize
-- @param  self

-----------------------
-- @function [parent=#CCEGLViewProtocol] setFrameSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCEGLViewProtocol] getVisibleSize
-- @param  self

-----------------------
-- @function [parent=#CCEGLViewProtocol] getVisibleOrigin
-- @param  self

-----------------------
-- @function [parent=#CCEGLViewProtocol] setDesignResolutionSize
-- @param  self
-- @param  width
-- @param  height
-- @param  resolutionPolicy

-----------------------
-- @function [parent=#CCEGLViewProtocol] getDesignResolutionSize
-- @param  self

-----------------------
-- @function [parent=#CCEGLViewProtocol] setViewPortInPoints
-- @param  self
-- @param  x
-- @param  y
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCEGLViewProtocol] setScissorInPoints
-- @param  self
-- @param  x
-- @param  y
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCEGLViewProtocol] getViewPortRect
-- @param  self

-----------------------
-- @function [parent=#CCEGLViewProtocol] getScaleX
-- @param  self

-----------------------
-- @function [parent=#CCEGLViewProtocol] getScaleY
-- @param  self

-----------------------
return nil
