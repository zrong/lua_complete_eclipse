-- @module CCMovementBoneData

-----------------------
-- @function [parent=#CCMovementBoneData] addFrameData
-- @param  self
-- @param  frameData

-----------------------
return nil
