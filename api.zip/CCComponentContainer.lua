-- @module CCComponentContainer

-----------------------
-- @function [parent=#CCComponentContainer] get
-- @param  self
-- @param  pName

-----------------------
-- @function [parent=#CCComponentContainer] add
-- @param  self
-- @param  pCom

-----------------------
-- @function [parent=#CCComponentContainer] remove
-- @param  self
-- @param  pName

-----------------------
-- @function [parent=#CCComponentContainer] removeAll
-- @param  self

-----------------------
-- @function [parent=#CCComponentContainer] visit
-- @param  self
-- @param  fDelta

-----------------------
-- @function [parent=#CCComponentContainer] isEmpty
-- @param  self

-----------------------
return nil
