-- @module CCScale9Sprite

-----------------------
-- @function [parent=#CCScale9Sprite] getOriginalSize
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] getPreferredSize
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] setPreferredSize
-- @param  self
-- @param  s

-----------------------
-- @function [parent=#CCScale9Sprite] getCapInsets
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] setCapInsets
-- @param  self
-- @param  rect

-----------------------
-- @function [parent=#CCScale9Sprite] getInsetLeft
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] setInsetLeft
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCScale9Sprite] getInsetTop
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] setInsetTop
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCScale9Sprite] getInsetRight
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] setInsetRight
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCScale9Sprite] getInsetBottom
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] setInsetBottom
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCScale9Sprite] setContentSize
-- @param  self
-- @param  size

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file
-- @param  rect
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file
-- @param  rect

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrame
-- @param  spriteFrame
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrame
-- @param  spriteFrame

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrameName
-- @param  spriteFrameName
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrameName
-- @param  spriteFrameName

-----------------------
-- @function [parent=#CCScale9Sprite] create

-----------------------
-- @function [parent=#CCScale9Sprite] resizableSpriteWithCapInsets
-- @param  self
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] glColor
-- @param  self
-- @param  R
-- @param  G
-- @param  B
-- @param  opacity

-----------------------
-- @function [parent=#CCScale9Sprite] glColor
-- @param  self
-- @param  opacity
-- @param  opacity
-- @param  opacity
-- @param  opacity

-----------------------
-- @function [parent=#CCScale9Sprite] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCScale9Sprite] glColor
-- @param  self
-- @param  R
-- @param  G
-- @param  B
-- @param  opacity

-----------------------
-- @function [parent=#CCScale9Sprite] glColor
-- @param  self
-- @param  opacity
-- @param  opacity
-- @param  opacity
-- @param  opacity

-----------------------
-- @function [parent=#CCScale9Sprite] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCScale9Sprite] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCScale9Sprite] getColor
-- @param  self

-----------------------
-- @function [parent=#CCScale9Sprite] setSpriteFrame
-- @param  self
-- @param  spriteFrame

-----------------------
return nil
