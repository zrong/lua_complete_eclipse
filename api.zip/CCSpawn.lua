-- @module CCSpawn

-----------------------
-- @function [parent=#CCSpawn] create
-- @param  arrayOfActions

-----------------------
-- @function [parent=#CCSpawn] createWithTwoActions
-- @param  pAction1
-- @param  pAction2

-----------------------
return nil
