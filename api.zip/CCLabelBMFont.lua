-- @module CCLabelBMFont

-----------------------
-- @function [parent=#CCLabelBMFont] CCLabelBMFont
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] init
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] initWithString
-- @param  self
-- @param  str
-- @param  fntFile
-- @param  kCCLabelAutomaticWidth
-- @param  kCCTextAlignmentLeft
-- @param  0
-- @param  0

-----------------------
-- @function [parent=#CCLabelBMFont] purgeCachedData

-----------------------
-- @function [parent=#CCLabelBMFont] create
-- @param  text
-- @param  fntFile
-- @param  width
-- @param  alignment
-- @param  imageOffset

-----------------------
-- @function [parent=#CCLabelBMFont] create
-- @param  text
-- @param  fntFile
-- @param  width
-- @param  alignment

-----------------------
-- @function [parent=#CCLabelBMFont] create
-- @param  text
-- @param  fntFile
-- @param  width

-----------------------
-- @function [parent=#CCLabelBMFont] create
-- @param  text
-- @param  fntFile

-----------------------
-- @function [parent=#CCLabelBMFont] create

-----------------------
-- @function [parent=#CCLabelBMFont] setString
-- @param  self
-- @param  newString
-- @param  needUpdateLabel

-----------------------
-- @function [parent=#CCLabelBMFont] setString
-- @param  self
-- @param  newString

-----------------------
-- @function [parent=#CCLabelBMFont] getString
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelBMFont] setCString
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCLabelBMFont] updateLabel
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] setAlignment
-- @param  self
-- @param  alignment

-----------------------
-- @function [parent=#CCLabelBMFont] setWidth
-- @param  self
-- @param  width

-----------------------
-- @function [parent=#CCLabelBMFont] setLineBreakWithoutSpace
-- @param  self
-- @param  breakWithoutSpace

-----------------------
-- @function [parent=#CCLabelBMFont] isOpacityModifyRGB
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] setOpacityModifyRGB
-- @param  self
-- @param  isOpacityModifyRGB

-----------------------
-- @function [parent=#CCLabelBMFont] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] getDisplayedOpacity
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCLabelBMFont] updateDisplayedOpacity
-- @param  self
-- @param  parentOpacity

-----------------------
-- @function [parent=#CCLabelBMFont] isCascadeOpacityEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] setCascadeOpacityEnabled
-- @param  self
-- @param  cascadeOpacityEnabled

-----------------------
-- @function [parent=#CCLabelBMFont] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelBMFont] getDisplayedColor
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCLabelBMFont] updateDisplayedColor
-- @param  self
-- @param  parentColor

-----------------------
-- @function [parent=#CCLabelBMFont] isCascadeColorEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] setCascadeColorEnabled
-- @param  self
-- @param  cascadeColorEnabled

-----------------------
-- @function [parent=#CCLabelBMFont] setFntFile
-- @param  self
-- @param  fntFile

-----------------------
-- @function [parent=#CCLabelBMFont] getFntFile
-- @param  self

-----------------------
return nil
