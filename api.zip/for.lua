-- @module for

-----------------------
-- @function [parent=#for] create
-- @param  label
-- @param  target
-- @param  selector

-----------------------
-- @function [parent=#for] create
-- @param  label

-----------------------
-- @function [parent=#for] getDisabledColor
-- @param  self

-----------------------
-- @function [parent=#for] setDisabledColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#for] getLabel
-- @param  self

-----------------------
-- @function [parent=#for] setLabel
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#for] setString
-- @param  self
-- @param  label

-----------------------
return nil
