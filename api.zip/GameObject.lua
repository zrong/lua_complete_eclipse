-- @module GameObject

-----------------------
-- @function [parent=#GameObject] extend
-- @param  target

-----------------------
return nil
