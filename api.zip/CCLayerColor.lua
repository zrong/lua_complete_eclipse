-- @module CCLayerColor

-----------------------
-- @function [parent=#CCLayerColor] changeWidth
-- @param  self
-- @param  w

-----------------------
-- @function [parent=#CCLayerColor] changeHeight
-- @param  self
-- @param  h

-----------------------
-- @function [parent=#CCLayerColor] changeWidthAndHeight
-- @param  self
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCLayerColor] setContentSize
-- @param  self
-- @param  var

-----------------------
-- @function [parent=#CCLayerColor] setOpacity
-- @param  self
-- @param  var

-----------------------
-- @function [parent=#CCLayerColor] getOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerColor] setColor
-- @param  self
-- @param  Value

-----------------------
-- @function [parent=#CCLayerColor] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerColor] setBlendFunc
-- @param  self
-- @param  Value

-----------------------
-- @function [parent=#CCLayerColor] getBlendFunc
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerColor] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCLayerColor] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerColor] create
-- @param  color
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCLayerColor] create
-- @param  color

-----------------------
return nil
