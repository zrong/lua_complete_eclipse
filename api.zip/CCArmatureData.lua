-- @module CCArmatureData

-----------------------
-- @function [parent=#CCArmatureData] addBoneData
-- @param  self
-- @param  boneData

-----------------------
return nil
