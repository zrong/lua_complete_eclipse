-- @module UICheckBoxButtonGroup

-----------------------
-- @field [parent=#UICheckBoxButtonGroup] BUTTON_SELECT_CHANGED

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] ctor
-- @param  self
-- @param  direction

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] addButton
-- @param  self
-- @param  button

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] removeButtonAtIndex
-- @param  self
-- @param  index

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] getButtonAtIndex
-- @param  self
-- @param  index

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] getButtonsCount
-- @param  self

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] setButtonsLayoutMargin
-- @param  self
-- @param  top
-- @param  right
-- @param  bottom
-- @param  left

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] addButtonSelectChangedEventListener
-- @param  self
-- @param  callback
-- @param  isWeakReference

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] onButtonSelectChanged
-- @param  self
-- @param  callback
-- @param  isWeakReference

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] onButtonStateChanged_
-- @param  self
-- @param  event

-----------------------
-- @function [parent=#UICheckBoxButtonGroup] updateButtonState_
-- @param  self
-- @param  clickedButton

-----------------------
return nil
