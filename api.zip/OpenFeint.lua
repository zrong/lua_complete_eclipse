-- @module OpenFeint

-----------------------
return nil
