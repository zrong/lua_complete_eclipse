-- @module UILayout

-----------------------
-- @function [parent=#UILayout] ctor
-- @param  self
-- @param  name

-----------------------
-- @function [parent=#UILayout] getName
-- @param  self

-----------------------
-- @function [parent=#UILayout] addLayout
-- @param  self
-- @param  layout
-- @param  weight

-----------------------
-- @function [parent=#UILayout] addWidget
-- @param  self
-- @param  widget
-- @param  weight

-----------------------
-- @function [parent=#UILayout] removeWidget
-- @param  self
-- @param  widget

-----------------------
-- @function [parent=#UILayout] addStretch
-- @param  self
-- @param  weight

-----------------------
-- @function [parent=#UILayout] getPosition
-- @param  self

-----------------------
-- @function [parent=#UILayout] getPositionX
-- @param  self

-----------------------
-- @function [parent=#UILayout] getPositionY
-- @param  self

-----------------------
-- @function [parent=#UILayout] setPosition
-- @param  self
-- @param  x
-- @param  y

-----------------------
-- @function [parent=#UILayout] setPositionX
-- @param  self
-- @param  x

-----------------------
-- @function [parent=#UILayout] setPositionY
-- @param  self
-- @param  y

-----------------------
-- @function [parent=#UILayout] getAnchorPoint
-- @param  self

-----------------------
-- @function [parent=#UILayout] setAnchorPoint
-- @param  self
-- @param  ap

-----------------------
-- @function [parent=#UILayout] apply
-- @param  self
-- @param  container

-----------------------
return nil
