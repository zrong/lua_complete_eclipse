-- @module CCTransitionScene

-----------------------
-- @function [parent=#CCTransitionScene] create
-- @param  t
-- @param  scene

-----------------------
return nil
