-- @module UIImage

-----------------------
-- @function [parent=#UIImage] ctor
-- @param  self
-- @param  filename
-- @param  options

-----------------------
-- @function [parent=#UIImage] setLayoutSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
return nil
