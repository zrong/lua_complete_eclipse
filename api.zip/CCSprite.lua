-- @module CCSprite

-----------------------
-- @function [parent=#CCSprite] create
-- @param  pszFileName
-- @param  rect

-----------------------
-- @function [parent=#CCSprite] create
-- @param  pszFileName

-----------------------
-- @function [parent=#CCSprite] create

-----------------------
-- @function [parent=#CCSprite] createWithTexture
-- @param  pTexture
-- @param  rect

-----------------------
-- @function [parent=#CCSprite] createWithTexture
-- @param  pTexture

-----------------------
-- @function [parent=#CCSprite] createWithSpriteFrame
-- @param  pSpriteFrame

-----------------------
-- @function [parent=#CCSprite] createWithSpriteFrameName
-- @param  pszSpriteFrameName

-----------------------
return nil
