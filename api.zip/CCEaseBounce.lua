-- @module CCEaseBounce

-----------------------
-- @function [parent=#CCEaseBounce] create
-- @param  pAction

-----------------------
return nil
