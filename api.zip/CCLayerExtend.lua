-- @module CCLayerExtend

-----------------------
-- @field [parent=#CCLayerExtend] __index

-----------------------
-- @function [parent=#CCLayerExtend] extend
-- @param  target

-----------------------
return nil
