-- @module CCCallFunc

-----------------------
-- @function [parent=#CCCallFunc] create
-- @param  nHandler

-----------------------
return nil
