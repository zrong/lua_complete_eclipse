-- @module CCEaseBackOut

-----------------------
-- @function [parent=#CCEaseBackOut] create
-- @param  pAction

-----------------------
return nil
