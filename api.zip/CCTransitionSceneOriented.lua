-- @module CCTransitionSceneOriented

-----------------------
-- @function [parent=#CCTransitionSceneOriented] create
-- @param  t
-- @param  scene
-- @param  orientation

-----------------------
return nil
