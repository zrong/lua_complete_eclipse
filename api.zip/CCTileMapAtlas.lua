-- @module CCTileMapAtlas

-----------------------
-- @function [parent=#CCTileMapAtlas] setTile
-- @param  self
-- @param  tile
-- @param  position

-----------------------
-- @function [parent=#CCTileMapAtlas] releaseMap
-- @param  self

-----------------------
-- @function [parent=#CCTileMapAtlas] tileAt
-- @param  self
-- @param  pos

-----------------------
-- @function [parent=#CCTileMapAtlas] create
-- @param  tile
-- @param  mapFile
-- @param  tileWidth
-- @param  tileHeight

-----------------------
return nil
