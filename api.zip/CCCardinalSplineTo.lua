-- @module CCCardinalSplineTo

-----------------------
-- @function [parent=#CCCardinalSplineTo] create
-- @param  duration
-- @param  points
-- @param  tension

-----------------------
-- @function [parent=#CCCardinalSplineTo] getPoints
-- @param  self

-----------------------
-- @function [parent=#CCCardinalSplineTo] setPoints
-- @param  self
-- @param  points

-----------------------
return nil
