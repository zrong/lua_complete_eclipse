-- @module CCParticleRain

-----------------------
-- @function [parent=#CCParticleRain] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleRain] create

-----------------------
return nil
