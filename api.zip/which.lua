-- @module which

-----------------------
-- @function [parent=#which] create
-- @param  tmxFile

-----------------------
-- @function [parent=#which] createWithXML
-- @param  tmxString
-- @param  resourcePath

-----------------------
-- @function [parent=#which] layerNamed
-- @param  self
-- @param  layerName

-----------------------
-- @function [parent=#which] objectGroupNamed
-- @param  self
-- @param  groupName

-----------------------
-- @function [parent=#which] propertiesForGID
-- @param  self
-- @param  GID

-----------------------
-- @function [parent=#which] getMapSize
-- @param  self

-----------------------
-- @function [parent=#which] getTileSize
-- @param  self

-----------------------
-- @function [parent=#which] getMapOrientation
-- @param  self

-----------------------
-- @function [parent=#which] getObjectGroups
-- @param  self

-----------------------
-- @function [parent=#which] getProperties
-- @param  self

-----------------------
return nil
