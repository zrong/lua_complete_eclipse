-- @module CCTransitionFlipAngular

-----------------------
-- @function [parent=#CCTransitionFlipAngular] create
-- @param  t
-- @param  s
-- @param  o

-----------------------
-- @function [parent=#CCTransitionFlipAngular] create
-- @param  t
-- @param  s

-----------------------
return nil
