-- @module CCBatchNode

-----------------------
return nil
