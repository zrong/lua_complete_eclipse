-- @module CCEditBox

-----------------------
-- @function [parent=#CCEditBox] create
-- @param  size
-- @param  pNormal9SpriteBg
-- @param  NULL
-- @param  NULL

-----------------------
-- @function [parent=#CCEditBox] onExit
-- @param  self

-----------------------
-- @function [parent=#CCEditBox] editboxEventHandler
-- @param  self
-- @param  eventType

-----------------------
-- @function [parent=#CCEditBox] registerScriptEditBoxHandler
-- @param  self
-- @param  editboxEventHandler

-----------------------
-- @function [parent=#CCEditBox] registerScriptEditBoxHandler
-- @param  self
-- @param  handler

-----------------------
-- @function [parent=#CCEditBox] unregisterScriptEditBoxHandler
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCEditBox] setText
-- @param  self
-- @param  pText

-----------------------
-- @function [parent=#CCEditBox] getText
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCEditBox] setFont
-- @param  self
-- @param  pFontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCEditBox] setFontName
-- @param  self
-- @param  pFontName

-----------------------
-- @function [parent=#CCEditBox] setFontSize
-- @param  self
-- @param  fontSize

-----------------------
-- @function [parent=#CCEditBox] setFontColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCEditBox] setPlaceholderFont
-- @param  self
-- @param  pFontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCEditBox] setPlaceholderFontName
-- @param  self
-- @param  pFontName

-----------------------
-- @function [parent=#CCEditBox] setPlaceholderFontSize
-- @param  self
-- @param  fontSize

-----------------------
-- @function [parent=#CCEditBox] setPlaceholderFontColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCEditBox] setPlaceHolder
-- @param  self
-- @param  pText

-----------------------
-- @function [parent=#CCEditBox] getPlaceHolder
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCEditBox] setInputMode
-- @param  self
-- @param  inputMode

-----------------------
-- @function [parent=#CCEditBox] setMaxLength
-- @param  self
-- @param  maxLength

-----------------------
-- @function [parent=#CCEditBox] getMaxLength
-- @param  self

-----------------------
-- @function [parent=#CCEditBox] setInputFlag
-- @param  self
-- @param  inputFlag

-----------------------
-- @function [parent=#CCEditBox] setReturnType
-- @param  self
-- @param  returnType

-----------------------
-- @function [parent=#CCEditBox] getReturnType
-- @param  self

-----------------------
return nil
