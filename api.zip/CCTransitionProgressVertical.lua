-- @module CCTransitionProgressVertical

-----------------------
-- @function [parent=#CCTransitionProgressVertical] create
-- @param  t
-- @param  scene

-----------------------
return nil
