-- @module CCMenuItemToggle

-----------------------
-- @function [parent=#CCMenuItemToggle] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemToggle] getColor
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemToggle] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCMenuItemToggle] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemToggle] setSelectedIndex
-- @param  self
-- @param  index

-----------------------
-- @function [parent=#CCMenuItemToggle] getSelectedIndex
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemToggle] setSubItems
-- @param  self
-- @param  pArrayOfItems

-----------------------
-- @function [parent=#CCMenuItemToggle] getSubItems
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemToggle] addSubItem
-- @param  self
-- @param  item

-----------------------
-- @function [parent=#CCMenuItemToggle] selectedItem
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemToggle] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCMenuItemToggle] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMenuItemToggle] create
-- @param  item

-----------------------
return nil
