-- @module ccBlendFunc

-----------------------
-- @function [parent=#ccBlendFunc] ccBlendFunc
-- @param  self

-----------------------
return nil
