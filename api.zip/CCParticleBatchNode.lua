-- @module CCParticleBatchNode

-----------------------
-- @function [parent=#CCParticleBatchNode] createWithTexture
-- @param  tex
-- @param  500

-----------------------
-- @function [parent=#CCParticleBatchNode] create
-- @param  fileImage
-- @param  500

-----------------------
-- @function [parent=#CCParticleBatchNode] insertChild
-- @param  self
-- @param  pSystem
-- @param  index

-----------------------
-- @function [parent=#CCParticleBatchNode] disableParticle
-- @param  self
-- @param  particleIndex

-----------------------
-- @function [parent=#CCParticleBatchNode] getTexture
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCParticleBatchNode] setTexture
-- @param  self
-- @param  texture

-----------------------
-- @function [parent=#CCParticleBatchNode] setBlendFunc
-- @param  self
-- @param  blendFunc

-----------------------
-- @function [parent=#CCParticleBatchNode] getBlendFunc
-- @param  self
-- @param  void

-----------------------
return nil
