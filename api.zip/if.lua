-- @module if

-----------------------
-- @function [parent=#if] sharedAnimationCache
-- @param  void

-----------------------
-- @function [parent=#if] purgeSharedAnimationCache
-- @param  void

-----------------------
-- @function [parent=#if] addAnimation
-- @param  self
-- @param  animation
-- @param  name

-----------------------
-- @function [parent=#if] removeAnimationByName
-- @param  self
-- @param  name

-----------------------
-- @function [parent=#if] animationByName
-- @param  self
-- @param  name

-----------------------
-- @function [parent=#if] addAnimationsWithDictionary
-- @param  self
-- @param  dictionary

-----------------------
-- @function [parent=#if] addAnimationsWithFile
-- @param  self
-- @param  plist

-----------------------
return nil
