-- @module from

-----------------------
-- @function [parent=#from] getState
-- @param  self

-----------------------
-- @function [parent=#from] setEnabled
-- @param  self
-- @param  bEnabled

-----------------------
-- @function [parent=#from] isEnabled
-- @param  self

-----------------------
-- @function [parent=#from] setSelected
-- @param  self
-- @param  bSelected

-----------------------
-- @function [parent=#from] isSelected
-- @param  self

-----------------------
-- @function [parent=#from] setHighlighted
-- @param  self
-- @param  bHighlighted

-----------------------
-- @function [parent=#from] isHighlighted
-- @param  self

-----------------------
-- @function [parent=#from] hasVisibleParents
-- @param  self

-----------------------
-- @function [parent=#from] isOpacityModifyRGB
-- @param  self

-----------------------
-- @function [parent=#from] setOpacityModifyRGB
-- @param  self
-- @param  bOpacityModifyRGB

-----------------------
-- @function [parent=#from] sendActionsForControlEvents
-- @param  self
-- @param  controlEvents

-----------------------
-- @function [parent=#from] addHandleOfControlEvent
-- @param  self
-- @param  nFunID
-- @param  controlEvent

-----------------------
-- @function [parent=#from] removeHandleOfControlEvent
-- @param  self
-- @param  controlEvent

-----------------------
return nil
