-- @module ccColor4B

-----------------------
-- @function [parent=#ccColor4B] ccColor4B
-- @param  self

-----------------------
return nil
