-- @module of

-----------------------
-- @function [parent=#of] CCTMXLayer
-- @param  self

-----------------------
-- @function [parent=#of] create
-- @param  tilesetInfo
-- @param  layerInfo
-- @param  mapInfo

-----------------------
-- @function [parent=#of] initWithTilesetInfo
-- @param  self
-- @param  tilesetInfo
-- @param  layerInfo
-- @param  mapInfo

-----------------------
-- @function [parent=#of] getLayerSize
-- @param  self

-----------------------
-- @function [parent=#of] getMapTileSize
-- @param  self

-----------------------
-- @function [parent=#of] getLayerOrientation
-- @param  self

-----------------------
-- @function [parent=#of] releaseMap
-- @param  self

-----------------------
-- @function [parent=#of] tileAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#of] tileGIDAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#of] setTileGID
-- @param  self
-- @param  gid
-- @param  tileCoordinate

-----------------------
-- @function [parent=#of] removeTileAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#of] positionAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#of] getLayerName
-- @param  self

-----------------------
return nil
