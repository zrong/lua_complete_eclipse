-- @module CCTransitionSplitCols

-----------------------
-- @function [parent=#CCTransitionSplitCols] create
-- @param  t
-- @param  scene

-----------------------
return nil
