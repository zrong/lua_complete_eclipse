-- @module CCParticleFlower

-----------------------
-- @function [parent=#CCParticleFlower] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleFlower] create

-----------------------
return nil
