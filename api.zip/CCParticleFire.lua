-- @module CCParticleFire

-----------------------
-- @function [parent=#CCParticleFire] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleFire] create

-----------------------
return nil
