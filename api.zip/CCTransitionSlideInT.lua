-- @module CCTransitionSlideInT

-----------------------
-- @function [parent=#CCTransitionSlideInT] create
-- @param  t
-- @param  scene

-----------------------
return nil
