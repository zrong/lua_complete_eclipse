-- @module CCFlipX3D

-----------------------
-- @function [parent=#CCFlipX3D] create
-- @param  duration

-----------------------
return nil
