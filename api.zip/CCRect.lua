-- @module CCRect

-----------------------
-- @function [parent=#CCRect] CCRect
-- @param  self
-- @param  x
-- @param  y
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCRect] CCRect
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCRect] CCRect
-- @param  self

-----------------------
-- @function [parent=#CCRect] setRect
-- @param  self
-- @param  x
-- @param  y
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCRect] getMinX
-- @param  self

-----------------------
-- @function [parent=#CCRect] getMidX
-- @param  self

-----------------------
-- @function [parent=#CCRect] getMaxX
-- @param  self

-----------------------
-- @function [parent=#CCRect] getMinY
-- @param  self

-----------------------
-- @function [parent=#CCRect] getMidY
-- @param  self

-----------------------
-- @function [parent=#CCRect] getMaxY
-- @param  self

-----------------------
-- @function [parent=#CCRect] equals
-- @param  self
-- @param  rect

-----------------------
-- @function [parent=#CCRect] containsPoint
-- @param  self
-- @param  point

-----------------------
-- @function [parent=#CCRect] intersectsRect
-- @param  self
-- @param  rect

-----------------------
return nil
