-- @module CCSplitCols

-----------------------
-- @function [parent=#CCSplitCols] create
-- @param  duration
-- @param  nCols

-----------------------
return nil
