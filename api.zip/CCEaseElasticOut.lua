-- @module CCEaseElasticOut

-----------------------
-- @function [parent=#CCEaseElasticOut] create
-- @param  pAction
-- @param  fPeriod

-----------------------
-- @function [parent=#CCEaseElasticOut] create
-- @param  pAction

-----------------------
return nil
