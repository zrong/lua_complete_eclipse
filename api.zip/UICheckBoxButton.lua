-- @module UICheckBoxButton

-----------------------
-- @field [parent=#UICheckBoxButton] OFF

-----------------------
-- @field [parent=#UICheckBoxButton] OFF_PRESSED

-----------------------
-- @field [parent=#UICheckBoxButton] OFF_DISABLED

-----------------------
-- @field [parent=#UICheckBoxButton] ON

-----------------------
-- @field [parent=#UICheckBoxButton] ON_PRESSED

-----------------------
-- @field [parent=#UICheckBoxButton] ON_DISABLED

-----------------------
-- @function [parent=#UICheckBoxButton] ctor
-- @param  self
-- @param  images
-- @param  options

-----------------------
-- @function [parent=#UICheckBoxButton] setButtonImage
-- @param  self
-- @param  state
-- @param  image
-- @param  ignoreEmpty

-----------------------
-- @function [parent=#UICheckBoxButton] isButtonSelected
-- @param  self

-----------------------
-- @function [parent=#UICheckBoxButton] setButtonSelected
-- @param  self
-- @param  selected

-----------------------
-- @function [parent=#UICheckBoxButton] onTouch_
-- @param  self
-- @param  event
-- @param  x
-- @param  y

-----------------------
-- @function [parent=#UICheckBoxButton] getDefaultState_
-- @param  self

-----------------------
return nil
