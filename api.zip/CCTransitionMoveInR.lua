-- @module CCTransitionMoveInR

-----------------------
-- @function [parent=#CCTransitionMoveInR] create
-- @param  t
-- @param  scene

-----------------------
return nil
