-- @module BasicLayoutProtocol

-----------------------
-- @function [parent=#BasicLayoutProtocol] ctor
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] getLayoutSize
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] setLayoutSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#BasicLayoutProtocol] getLayoutMinSize
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] setLayoutMinSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#BasicLayoutProtocol] getLayoutMaxSize
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] setLayoutMaxSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#BasicLayoutProtocol] getLayoutSizePolicy
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] setLayoutSizePolicy
-- @param  self
-- @param  horizontal
-- @param  vertical

-----------------------
-- @function [parent=#BasicLayoutProtocol] getLayoutPadding
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] setLayoutPadding
-- @param  self
-- @param  top
-- @param  right
-- @param  bottom
-- @param  left

-----------------------
-- @function [parent=#BasicLayoutProtocol] getLayoutMargin
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] setLayoutMargin
-- @param  self
-- @param  top
-- @param  right
-- @param  bottom
-- @param  left

-----------------------
-- @function [parent=#BasicLayoutProtocol] exportMethods
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] onBind_
-- @param  self

-----------------------
-- @function [parent=#BasicLayoutProtocol] onUnbind_
-- @param  self

-----------------------
return nil
