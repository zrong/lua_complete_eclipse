-- @module CCMenuItemAtlasFont

-----------------------
return nil
