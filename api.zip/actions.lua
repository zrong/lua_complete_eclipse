-- @module actions

-----------------------
-- @function [parent=#actions] getDuration
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#actions] reverse
-- @param  self
-- @param  void

-----------------------
return nil
