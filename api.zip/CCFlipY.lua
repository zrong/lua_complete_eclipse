-- @module CCFlipY

-----------------------
-- @function [parent=#CCFlipY] create
-- @param  y

-----------------------
return nil
