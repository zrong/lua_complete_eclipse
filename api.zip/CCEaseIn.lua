-- @module CCEaseIn

-----------------------
-- @function [parent=#CCEaseIn] create
-- @param  pAction
-- @param  fRate

-----------------------
return nil
