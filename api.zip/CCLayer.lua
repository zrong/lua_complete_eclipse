-- @module CCLayer

-----------------------
-- @function [parent=#CCLayer] setTouchEnabled
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCLayer] isTouchEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLayer] setAccelerometerEnabled
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCLayer] isAccelerometerEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLayer] setKeypadEnabled
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCLayer] isKeypadEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLayer] setTouchPriority
-- @param  self
-- @param  priority

-----------------------
-- @function [parent=#CCLayer] getTouchPriority
-- @param  self

-----------------------
-- @function [parent=#CCLayer] unregisterScriptTouchHandler
-- @param  self

-----------------------
-- @function [parent=#CCLayer] registerScriptKeypadHandler
-- @param  self
-- @param  nHandler

-----------------------
-- @function [parent=#CCLayer] unregisterScriptKeypadHandler
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayer] registerScriptAccelerateHandler
-- @param  self
-- @param  nHandler

-----------------------
-- @function [parent=#CCLayer] unregisterScriptAccelerateHandler
-- @param  self
-- @param  void

-----------------------
return nil
