-- @module CCTransitionZoomFlipX

-----------------------
-- @function [parent=#CCTransitionZoomFlipX] create
-- @param  t
-- @param  s
-- @param  o

-----------------------
-- @function [parent=#CCTransitionZoomFlipX] create
-- @param  t
-- @param  s

-----------------------
return nil
