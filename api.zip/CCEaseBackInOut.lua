-- @module CCEaseBackInOut

-----------------------
-- @function [parent=#CCEaseBackInOut] create
-- @param  pAction

-----------------------
return nil
