-- @module CCFloat

-----------------------
-- @function [parent=#CCFloat] CCFloat
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCFloat] getValue
-- @param  self

-----------------------
-- @function [parent=#CCFloat] create
-- @param  v

-----------------------
return nil
