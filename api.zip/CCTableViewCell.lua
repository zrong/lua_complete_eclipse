-- @module CCTableViewCell

-----------------------
-- @function [parent=#CCTableViewCell] getIdx
-- @param  self

-----------------------
-- @function [parent=#CCTableViewCell] setIdx
-- @param  self
-- @param  uIdx

-----------------------
-- @function [parent=#CCTableViewCell] reset
-- @param  self

-----------------------
-- @function [parent=#CCTableViewCell] setObjectID
-- @param  self
-- @param  uIdx

-----------------------
-- @function [parent=#CCTableViewCell] getObjectID
-- @param  self

-----------------------
return nil
