-- @module CCAnimationFrame

-----------------------
-- @function [parent=#CCAnimationFrame] getSpriteFrame
-- @param  self

-----------------------
-- @function [parent=#CCAnimationFrame] setSpriteFrame
-- @param  self
-- @param  frame

-----------------------
-- @function [parent=#CCAnimationFrame] getDelayUnits
-- @param  self

-----------------------
-- @function [parent=#CCAnimationFrame] setDelayUnits
-- @param  self
-- @param  delay

-----------------------
return nil
