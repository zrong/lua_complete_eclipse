-- @module CCProgressTo

-----------------------
-- @function [parent=#CCProgressTo] create
-- @param  duration
-- @param  fPercent

-----------------------
return nil
