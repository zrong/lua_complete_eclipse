-- @module CCArmature

-----------------------
-- @function [parent=#CCArmature] addBone
-- @param  self
-- @param  bone
-- @param  parentName

-----------------------
-- @function [parent=#CCArmature] changeBoneParent
-- @param  self
-- @param  bone
-- @param  parentName

-----------------------
-- @function [parent=#CCArmature] removeBone
-- @param  self
-- @param  bone
-- @param  true

-----------------------
-- @function [parent=#CCArmature] boundingBox
-- @param  self

-----------------------
-- @function [parent=#CCArmature] getName
-- @param  self

-----------------------
return nil
