-- @module CCEaseBounceOut

-----------------------
-- @function [parent=#CCEaseBounceOut] create
-- @param  pAction

-----------------------
return nil
