-- @module CCFadeOutTRTiles

-----------------------
-- @function [parent=#CCFadeOutTRTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
