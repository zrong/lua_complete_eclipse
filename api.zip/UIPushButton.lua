-- @module UIPushButton

-----------------------
-- @field [parent=#UIPushButton] NORMAL

-----------------------
-- @field [parent=#UIPushButton] PRESSED

-----------------------
-- @field [parent=#UIPushButton] DISABLED

-----------------------
-- @function [parent=#UIPushButton] ctor
-- @param  self
-- @param  images
-- @param  options

-----------------------
-- @function [parent=#UIPushButton] setButtonImage
-- @param  self
-- @param  state
-- @param  image
-- @param  ignoreEmpty

-----------------------
-- @function [parent=#UIPushButton] onTouch_
-- @param  self
-- @param  event
-- @param  x
-- @param  y

-----------------------
return nil
