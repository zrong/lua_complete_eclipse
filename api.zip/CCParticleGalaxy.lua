-- @module CCParticleGalaxy

-----------------------
-- @function [parent=#CCParticleGalaxy] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleGalaxy] create

-----------------------
return nil
