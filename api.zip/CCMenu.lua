-- @module CCMenu

-----------------------
-- @function [parent=#CCMenu] create

-----------------------
-- @function [parent=#CCMenu] createWithArray
-- @param  pArrayOfItems

-----------------------
-- @function [parent=#CCMenu] addChild
-- @param  self

-----------------------
-- @function [parent=#CCMenu] createWithItem
-- @param  item

-----------------------
-- @function [parent=#CCMenu] alignItemsVertically
-- @param  self

-----------------------
-- @function [parent=#CCMenu] alignItemsVerticallyWithPadding
-- @param  self
-- @param  padding

-----------------------
-- @function [parent=#CCMenu] alignItemsHorizontally
-- @param  self

-----------------------
-- @function [parent=#CCMenu] alignItemsHorizontallyWithPadding
-- @param  self
-- @param  padding

-----------------------
-- @function [parent=#CCMenu] alignItemsInColumnsWithArray
-- @param  self
-- @param  rows

-----------------------
-- @function [parent=#CCMenu] alignItemsInRowsWithArray
-- @param  self
-- @param  columns

-----------------------
-- @function [parent=#CCMenu] setHandlerPriority
-- @param  self
-- @param  newPriority

-----------------------
-- @function [parent=#CCMenu] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCMenu] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMenu] isEnabled
-- @param  self

-----------------------
-- @function [parent=#CCMenu] setEnabled
-- @param  self
-- @param  value

-----------------------
return nil
