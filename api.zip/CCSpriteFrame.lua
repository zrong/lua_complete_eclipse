-- @module CCSpriteFrame

-----------------------
-- @function [parent=#CCSpriteFrame] getRectInPixels
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setRectInPixels
-- @param  self
-- @param  rectInPixels

-----------------------
-- @function [parent=#CCSpriteFrame] isRotated
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setRotated
-- @param  self
-- @param  bRotated

-----------------------
-- @function [parent=#CCSpriteFrame] getRect
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setRect
-- @param  self
-- @param  rect

-----------------------
-- @function [parent=#CCSpriteFrame] getOffsetInPixels
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setOffsetInPixels
-- @param  self
-- @param  offsetInPixels

-----------------------
-- @function [parent=#CCSpriteFrame] getOriginalSizeInPixels
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setOriginalSizeInPixels
-- @param  self
-- @param  sizeInPixels

-----------------------
-- @function [parent=#CCSpriteFrame] getOriginalSize
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setOriginalSize
-- @param  self
-- @param  sizeInPixels

-----------------------
-- @function [parent=#CCSpriteFrame] getTexture
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setTexture
-- @param  self
-- @param  pobTexture

-----------------------
-- @function [parent=#CCSpriteFrame] getOffset
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setOffset
-- @param  self
-- @param  offsets

-----------------------
-- @function [parent=#CCSpriteFrame] create
-- @param  filename
-- @param  rect
-- @param  rotated
-- @param  offset
-- @param  originalSize

-----------------------
-- @function [parent=#CCSpriteFrame] create
-- @param  filename
-- @param  rect

-----------------------
-- @function [parent=#CCSpriteFrame] createWithTexture
-- @param  pobTexture
-- @param  rect
-- @param  rotated
-- @param  offset
-- @param  originalSize

-----------------------
-- @function [parent=#CCSpriteFrame] createWithTexture
-- @param  pobTexture
-- @param  rect

-----------------------
return nil
