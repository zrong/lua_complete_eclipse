-- @module CCPoint

-----------------------
-- @function [parent=#CCPoint] CCPoint
-- @param  self
-- @param  x
-- @param  y

-----------------------
-- @function [parent=#CCPoint] CCPoint
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] CCPoint
-- @param  self
-- @param  size

-----------------------
-- @function [parent=#CCPoint] CCPoint
-- @param  self

-----------------------
-- @function [parent=#CCPoint] setPoint
-- @param  self
-- @param  x
-- @param  y

-----------------------
-- @function [parent=#CCPoint] equals
-- @param  self
-- @param  target

-----------------------
-- @function [parent=#CCPoint] fuzzyEquals
-- @param  self
-- @param  target
-- @param  variance

-----------------------
-- @function [parent=#CCPoint] getLength
-- @param  self

-----------------------
-- @function [parent=#CCPoint] sqrt
-- @param  self

-----------------------
-- @function [parent=#CCPoint] getLengthSq
-- @param  self

-----------------------
-- @function [parent=#CCPoint] sqrt
-- @param  self

-----------------------
-- @function [parent=#CCPoint] getDistanceSq
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] getDistance
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] getAngle
-- @param  self

-----------------------
-- @function [parent=#CCPoint] getAngle
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] dot
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] cross
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] cross
-- @param  self
-- @param  v
-- @param  v

-----------------------
-- @function [parent=#CCPoint] getPerp
-- @param  self

-----------------------
-- @function [parent=#CCPoint] cross
-- @param  self
-- @param  v
-- @param  v

-----------------------
-- @function [parent=#CCPoint] getRPerp
-- @param  self

-----------------------
-- @function [parent=#CCPoint] project
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] rotate
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] unrotate
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCPoint] normalize
-- @param  self

-----------------------
-- @function [parent=#CCPoint] lerp
-- @param  self
-- @param  other
-- @param  alpha

-----------------------
-- @function [parent=#CCPoint] rotateByAngle
-- @param  self
-- @param  pivot
-- @param  angle

-----------------------
-- @function [parent=#CCPoint] forAngle
-- @param  self
-- @param  a

-----------------------
return nil
