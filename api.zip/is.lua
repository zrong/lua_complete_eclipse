-- @module is

-----------------------
-- @function [parent=#is] AssetsManager
-- @param  self
-- @param  NULL
-- @param  NULL
-- @param  NULL

-----------------------
-- @function [parent=#is] checkUpdate
-- @param  self

-----------------------
-- @function [parent=#is] update
-- @param  self

-----------------------
-- @function [parent=#is] getPackageUrl
-- @param  self

-----------------------
-- @function [parent=#is] setPackageUrl
-- @param  self
-- @param  packageUrl

-----------------------
-- @function [parent=#is] getVersionFileUrl
-- @param  self

-----------------------
-- @function [parent=#is] setVersionFileUrl
-- @param  self
-- @param  versionFileUrl

-----------------------
-- @function [parent=#is] getVersion
-- @param  self

-----------------------
-- @function [parent=#is] deleteVersion
-- @param  self

-----------------------
-- @function [parent=#is] getStoragePath
-- @param  self

-----------------------
-- @function [parent=#is] setStoragePath
-- @param  self
-- @param  storagePath

-----------------------
-- @function [parent=#is] setConnectionTimeout
-- @param  self
-- @param  timeout

-----------------------
-- @function [parent=#is] getConnectionTimeout
-- @param  self

-----------------------
-- @function [parent=#is] registerScriptHandler
-- @param  self
-- @param  handler

-----------------------
-- @function [parent=#is] unregisterScriptHandler
-- @param  self
-- @param  void

-----------------------
return nil
