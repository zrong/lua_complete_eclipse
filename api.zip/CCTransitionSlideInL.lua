-- @module CCTransitionSlideInL

-----------------------
-- @function [parent=#CCTransitionSlideInL] create
-- @param  t
-- @param  scene

-----------------------
return nil
