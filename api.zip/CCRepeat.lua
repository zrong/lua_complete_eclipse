-- @module CCRepeat

-----------------------
-- @function [parent=#CCRepeat] pow
-- @param  self
-- @param  2
-- @param  30

-----------------------
-- @function [parent=#CCRepeat] create
-- @param  pAction
-- @param  times

-----------------------
return nil
