-- @module CCNode

-----------------------
-- @function [parent=#CCNode] create
-- @param  void

-----------------------
return nil
