-- @module CCTransitionFlipY

-----------------------
-- @function [parent=#CCTransitionFlipY] create
-- @param  t
-- @param  s
-- @param  o

-----------------------
-- @function [parent=#CCTransitionFlipY] create
-- @param  t
-- @param  s

-----------------------
return nil
