-- @module CCProgressFromTo

-----------------------
-- @function [parent=#CCProgressFromTo] create
-- @param  duration
-- @param  fFromPercentage
-- @param  fToPercentage

-----------------------
return nil
