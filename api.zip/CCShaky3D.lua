-- @module CCShaky3D

-----------------------
-- @function [parent=#CCShaky3D] create
-- @param  duration
-- @param  gridSize
-- @param  range
-- @param  shakeZ

-----------------------
return nil
