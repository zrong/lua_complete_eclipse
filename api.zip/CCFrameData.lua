-- @module CCFrameData

-----------------------
-- @function [parent=#CCFrameData] copy
-- @param  self
-- @param  frameData

-----------------------
return nil
