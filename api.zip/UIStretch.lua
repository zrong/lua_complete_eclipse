-- @module UIStretch

-----------------------
-- @function [parent=#UIStretch] ctor
-- @param  self

-----------------------
-- @function [parent=#UIStretch] getPosition
-- @param  self

-----------------------
-- @function [parent=#UIStretch] getPositionX
-- @param  self

-----------------------
-- @function [parent=#UIStretch] getPositionY
-- @param  self

-----------------------
-- @function [parent=#UIStretch] setPosition
-- @param  self
-- @param  x
-- @param  y

-----------------------
-- @function [parent=#UIStretch] setPositionX
-- @param  self
-- @param  x

-----------------------
-- @function [parent=#UIStretch] setPositionY
-- @param  self
-- @param  y

-----------------------
-- @function [parent=#UIStretch] getAnchorPoint
-- @param  self

-----------------------
-- @function [parent=#UIStretch] setAnchorPoint
-- @param  self
-- @param  ap

-----------------------
return nil
