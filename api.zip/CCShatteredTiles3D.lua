-- @module CCShatteredTiles3D

-----------------------
-- @function [parent=#CCShatteredTiles3D] create
-- @param  duration
-- @param  gridSize
-- @param  nRange
-- @param  bShatterZ

-----------------------
return nil
