-- @module CCUserDefault

-----------------------
-- @function [parent=#CCUserDefault] getBoolForKey
-- @param  self
-- @param  pKey
-- @param  defaultValue

-----------------------
-- @function [parent=#CCUserDefault] getBoolForKey
-- @param  self
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] getIntegerForKey
-- @param  self
-- @param  pKey
-- @param  defaultValue

-----------------------
-- @function [parent=#CCUserDefault] getIntegerForKey
-- @param  self
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] getFloatForKey
-- @param  self
-- @param  pKey
-- @param  defaultValue

-----------------------
-- @function [parent=#CCUserDefault] getFloatForKey
-- @param  self
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] getDoubleForKey
-- @param  self
-- @param  pKey
-- @param  defaultValue

-----------------------
-- @function [parent=#CCUserDefault] getDoubleForKey
-- @param  self
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] getStringForKey
-- @param  self
-- @param  pKey
-- @param  defaultValue

-----------------------
-- @function [parent=#CCUserDefault] getStringForKey
-- @param  self
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] setBoolForKey
-- @param  self
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] setIntegerForKey
-- @param  self
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] setFloatForKey
-- @param  self
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] setDoubleForKey
-- @param  self
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] setStringForKey
-- @param  self
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] flush
-- @param  self

-----------------------
-- @function [parent=#CCUserDefault] sharedUserDefault

-----------------------
-- @function [parent=#CCUserDefault] purgeSharedUserDefault

-----------------------
-- @function [parent=#CCUserDefault] getXMLFilePath

-----------------------
-- @function [parent=#CCUserDefault] isXMLFileExist

-----------------------
return nil
