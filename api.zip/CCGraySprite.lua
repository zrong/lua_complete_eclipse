-- @module CCGraySprite

-----------------------
-- @function [parent=#CCGraySprite] create

-----------------------
-- @function [parent=#CCGraySprite] create
-- @param  pszFileName

-----------------------
-- @function [parent=#CCGraySprite] create
-- @param  pszFileName
-- @param  rect

-----------------------
-- @function [parent=#CCGraySprite] createWithTexture
-- @param  pTexture

-----------------------
-- @function [parent=#CCGraySprite] createWithTexture
-- @param  pTexture
-- @param  rect

-----------------------
-- @function [parent=#CCGraySprite] createWithSpriteFrame
-- @param  pSpriteFrame

-----------------------
-- @function [parent=#CCGraySprite] createWithSpriteFrameName
-- @param  pszSpriteFrameName

-----------------------
return nil
