-- @module UILabel

-----------------------
-- @function [parent=#UILabel] ctor
-- @param  self
-- @param  options

-----------------------
-- @function [parent=#UILabel] setLayoutSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
return nil
