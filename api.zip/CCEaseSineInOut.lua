-- @module CCEaseSineInOut

-----------------------
-- @function [parent=#CCEaseSineInOut] create
-- @param  pAction

-----------------------
return nil
