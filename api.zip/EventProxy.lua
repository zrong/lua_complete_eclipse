-- @module EventProxy

-----------------------
-- @function [parent=#EventProxy] ctor
-- @param  self
-- @param  eventDispatcher
-- @param  view

-----------------------
-- @function [parent=#EventProxy] addEventListener
-- @param  self
-- @param  eventName
-- @param  listener
-- @param  data

-----------------------
-- @function [parent=#EventProxy] removeEventListener
-- @param  self
-- @param  eventName
-- @param  key1
-- @param  key2

-----------------------
-- @function [parent=#EventProxy] removeAllEventListenersForEvent
-- @param  self
-- @param  eventName

-----------------------
-- @function [parent=#EventProxy] removeAllEventListeners
-- @param  self

-----------------------
return nil
