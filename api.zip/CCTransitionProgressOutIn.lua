-- @module CCTransitionProgressOutIn

-----------------------
-- @function [parent=#CCTransitionProgressOutIn] create
-- @param  t
-- @param  scene

-----------------------
return nil
