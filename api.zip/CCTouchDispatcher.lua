-- @module CCTouchDispatcher

-----------------------
-- @function [parent=#CCTouchDispatcher] removeAllDelegates
-- @param  self
-- @param  void

-----------------------
return nil
