-- @module CCString

-----------------------
-- @function [parent=#CCString] intValue
-- @param  self

-----------------------
-- @function [parent=#CCString] uintValue
-- @param  self

-----------------------
-- @function [parent=#CCString] floatValue
-- @param  self

-----------------------
-- @function [parent=#CCString] doubleValue
-- @param  self

-----------------------
-- @function [parent=#CCString] boolValue
-- @param  self

-----------------------
-- @function [parent=#CCString] getCString
-- @param  self

-----------------------
-- @function [parent=#CCString] length
-- @param  self

-----------------------
-- @function [parent=#CCString] compare
-- @param  self
-- @param  int

-----------------------
-- @function [parent=#CCString] isEqual
-- @param  self
-- @param  pObject

-----------------------
-- @function [parent=#CCString] create
-- @param  str

-----------------------
-- @function [parent=#CCString] createWithContentsOfFile
-- @param  pszFileName

-----------------------
return nil
