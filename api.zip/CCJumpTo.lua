-- @module CCJumpTo

-----------------------
-- @function [parent=#CCJumpTo] create
-- @param  duration
-- @param  position
-- @param  height
-- @param  jumps

-----------------------
return nil
