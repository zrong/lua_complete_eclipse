-- @module CCToggleVisibility

-----------------------
-- @function [parent=#CCToggleVisibility] create

-----------------------
return nil
