-- @module ccTexParams

-----------------------
-- @function [parent=#ccTexParams] ccTexParams
-- @param  self

-----------------------
return nil
