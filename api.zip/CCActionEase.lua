-- @module CCActionEase

-----------------------
-- @function [parent=#CCActionEase] create
-- @param  pAction

-----------------------
return nil
