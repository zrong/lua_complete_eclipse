-- @module Registry

-----------------------
-- @field [parent=#Registry] classes_

-----------------------
-- @function [parent=#Registry] add
-- @param  cls
-- @param  name

-----------------------
-- @function [parent=#Registry] remove
-- @param  name

-----------------------
-- @function [parent=#Registry] newObject
-- @param  name

-----------------------
return nil
