-- @module CCControlUtils

-----------------------
-- @function [parent=#CCControlUtils] HSVfromRGB
-- @param  value

-----------------------
-- @function [parent=#CCControlUtils] RGBfromHSV
-- @param  value

-----------------------
-- @function [parent=#CCControlUtils] CCRectUnion
-- @param  src1
-- @param  src2

-----------------------
return nil
