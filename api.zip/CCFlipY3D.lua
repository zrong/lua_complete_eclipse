-- @module CCFlipY3D

-----------------------
-- @function [parent=#CCFlipY3D] create
-- @param  duration

-----------------------
return nil
