-- @module CCCatmullRomTo

-----------------------
-- @function [parent=#CCCatmullRomTo] create
-- @param  dt
-- @param  points

-----------------------
return nil
