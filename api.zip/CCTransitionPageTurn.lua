-- @module CCTransitionPageTurn

-----------------------
-- @function [parent=#CCTransitionPageTurn] create
-- @param  t
-- @param  scene
-- @param  backwards

-----------------------
return nil
