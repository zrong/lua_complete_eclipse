-- @module CCRotateBy

-----------------------
-- @function [parent=#CCRotateBy] create
-- @param  fDuration
-- @param  fDeltaAngleX
-- @param  fDeltaAngleY

-----------------------
-- @function [parent=#CCRotateBy] create
-- @param  fDuration
-- @param  fDeltaAngle

-----------------------
return nil
