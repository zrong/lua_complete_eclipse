-- @module CCActionInstant

-----------------------
return nil
