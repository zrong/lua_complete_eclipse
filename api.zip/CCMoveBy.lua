-- @module CCMoveBy

-----------------------
-- @function [parent=#CCMoveBy] create
-- @param  duration
-- @param  deltaPosition

-----------------------
return nil
