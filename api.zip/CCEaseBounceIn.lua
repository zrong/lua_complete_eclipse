-- @module CCEaseBounceIn

-----------------------
-- @function [parent=#CCEaseBounceIn] create
-- @param  pAction

-----------------------
return nil
