-- @module CCTMXLayerInfo

-----------------------
-- @function [parent=#CCTMXLayerInfo] CCTMXLayerInfo
-- @param  self

-----------------------
return nil
