-- @module CCDictionary

-----------------------
-- @function [parent=#CCDictionary] count
-- @param  self

-----------------------
-- @function [parent=#CCDictionary] allKeys
-- @param  self

-----------------------
-- @function [parent=#CCDictionary] allKeysForObject
-- @param  self
-- @param  object

-----------------------
return nil
