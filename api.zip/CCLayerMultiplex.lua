-- @module CCLayerMultiplex

-----------------------
-- @function [parent=#CCLayerMultiplex] create

-----------------------
-- @function [parent=#CCLayerMultiplex] createWithArray
-- @param  arrayOfLayers

-----------------------
-- @function [parent=#CCLayerMultiplex] createWithLayer
-- @param  layer

-----------------------
-- @function [parent=#CCLayerMultiplex] addLayer
-- @param  self
-- @param  layer

-----------------------
-- @function [parent=#CCLayerMultiplex] switchTo
-- @param  self
-- @param  n

-----------------------
-- @function [parent=#CCLayerMultiplex] switchToAndReleaseMe
-- @param  self
-- @param  n

-----------------------
return nil
