-- @module CCActionInterval

-----------------------
return nil
