-- @module UIGroup

-----------------------
-- @function [parent=#UIGroup] ctor
-- @param  self

-----------------------
-- @function [parent=#UIGroup] addWidget
-- @param  self
-- @param  widget

-----------------------
-- @function [parent=#UIGroup] onTouch
-- @param  self
-- @param  listener

-----------------------
-- @function [parent=#UIGroup] enableTouch
-- @param  self
-- @param  enabled

-----------------------
-- @function [parent=#UIGroup] setLayoutSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#UIGroup] setBackgroundImage
-- @param  self
-- @param  filename
-- @param  args

-----------------------
return nil
