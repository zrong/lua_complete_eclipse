-- @module instead

-----------------------
-- @function [parent=#instead] ccBezierConfig
-- @param  self
-- @param  void

-----------------------
return nil
