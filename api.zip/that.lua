-- @module that

-----------------------
-- @function [parent=#that] create
-- @param  item

-----------------------
-- @function [parent=#that] create

-----------------------
-- @function [parent=#that] getSelectedIndex
-- @param  self

-----------------------
-- @function [parent=#that] setSelectedIndex
-- @param  self
-- @param  index

-----------------------
-- @function [parent=#that] getSubItems
-- @param  self

-----------------------
-- @function [parent=#that] addSubItem
-- @param  self
-- @param  item

-----------------------
-- @function [parent=#that] selectedItem
-- @param  self

-----------------------
return nil
