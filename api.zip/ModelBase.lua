-- @module ModelBase

-----------------------
-- @field [parent=#ModelBase] idkey

-----------------------
-- @field [parent=#ModelBase] schema

-----------------------
-- @field [parent=#ModelBase] fields

-----------------------
-- @function [parent=#ModelBase] ctor
-- @param  self
-- @param  properties

-----------------------
-- @function [parent=#ModelBase] getId
-- @param  self

-----------------------
-- @function [parent=#ModelBase] isValidId
-- @param  self

-----------------------
-- @function [parent=#ModelBase] setProperties
-- @param  self
-- @param  properties

-----------------------
-- @function [parent=#ModelBase] getProperties
-- @param  self
-- @param  fields
-- @param  filter

-----------------------
return nil
