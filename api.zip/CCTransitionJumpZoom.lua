-- @module CCTransitionJumpZoom

-----------------------
-- @function [parent=#CCTransitionJumpZoom] create
-- @param  t
-- @param  scene

-----------------------
return nil
