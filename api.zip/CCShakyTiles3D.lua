-- @module CCShakyTiles3D

-----------------------
-- @function [parent=#CCShakyTiles3D] create
-- @param  duration
-- @param  gridSize
-- @param  nRange
-- @param  bShakeZ

-----------------------
return nil
