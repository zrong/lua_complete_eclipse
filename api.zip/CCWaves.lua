-- @module CCWaves

-----------------------
-- @function [parent=#CCWaves] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude
-- @param  horizontal
-- @param  vertical

-----------------------
return nil
