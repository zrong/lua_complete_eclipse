-- @module CCBone

-----------------------
-- @function [parent=#CCBone] addDisplay
-- @param  self
-- @param  displayData
-- @param  index

-----------------------
-- @function [parent=#CCBone] changeDisplayByIndex
-- @param  self
-- @param  index
-- @param  force

-----------------------
-- @function [parent=#CCBone] setParent
-- @param  self
-- @param  _parent

-----------------------
-- @function [parent=#CCBone] addChildBone
-- @param  self
-- @param  _child

-----------------------
-- @function [parent=#CCBone] removeFromParent
-- @param  self
-- @param  true

-----------------------
-- @function [parent=#CCBone] removeChildBone
-- @param  self
-- @param  bone
-- @param  true

-----------------------
-- @function [parent=#CCBone] setIgnoreMovementBoneData
-- @param  self
-- @param  bool

-----------------------
-- @function [parent=#CCBone] getIgnoreMovementBoneData
-- @param  self

-----------------------
-- @function [parent=#CCBone] getName
-- @param  self

-----------------------
return nil
