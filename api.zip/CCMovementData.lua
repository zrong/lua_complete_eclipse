-- @module CCMovementData

-----------------------
-- @function [parent=#CCMovementData] addMovementBoneData
-- @param  self
-- @param  movBoneData

-----------------------
return nil
