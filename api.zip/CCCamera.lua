-- @module CCCamera

-----------------------
-- @function [parent=#CCCamera] CCCamera
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCamera] init
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCamera] setDirty
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCCamera] isDirty
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCamera] restore
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCamera] locate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCamera] setEyeXYZ
-- @param  self
-- @param  fEyeX
-- @param  fEyeY
-- @param  fEyeZ

-----------------------
-- @function [parent=#CCCamera] setCenterXYZ
-- @param  self
-- @param  fCenterX
-- @param  fCenterY
-- @param  fCenterZ

-----------------------
-- @function [parent=#CCCamera] setUpXYZ
-- @param  self
-- @param  fUpX
-- @param  fUpY
-- @param  fUpZ

-----------------------
-- @function [parent=#CCCamera] getEyeXYZ
-- @param  self
-- @param  pEyeX
-- @param  pEyeY
-- @param  pEyeZ

-----------------------
-- @function [parent=#CCCamera] getCenterXYZ
-- @param  self
-- @param  pCenterX
-- @param  pCenterY
-- @param  pCenterZ

-----------------------
-- @function [parent=#CCCamera] getUpXYZ
-- @param  self
-- @param  pUpX
-- @param  pUpY
-- @param  pUpZ

-----------------------
-- @function [parent=#CCCamera] getZEye

-----------------------
return nil
