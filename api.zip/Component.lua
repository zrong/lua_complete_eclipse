-- @module Component

-----------------------
-- @function [parent=#Component] ctor
-- @param  self
-- @param  name
-- @param  depends

-----------------------
-- @function [parent=#Component] getName
-- @param  self

-----------------------
-- @function [parent=#Component] getDepends
-- @param  self

-----------------------
-- @function [parent=#Component] getTarget
-- @param  self

-----------------------
-- @function [parent=#Component] exportMethods_
-- @param  self
-- @param  methods

-----------------------
-- @function [parent=#Component] bind_
-- @param  self
-- @param  target

-----------------------
-- @function [parent=#Component] unbind_
-- @param  self

-----------------------
-- @function [parent=#Component] onBind_
-- @param  self

-----------------------
-- @function [parent=#Component] onUnbind_
-- @param  self

-----------------------
return nil
