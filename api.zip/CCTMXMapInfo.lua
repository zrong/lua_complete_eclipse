-- @module CCTMXMapInfo

-----------------------
-- @function [parent=#CCTMXMapInfo] getOrientation
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getMapSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getTileSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getLayers
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getTilesets
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getObjectGroups
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getParentElement
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getParentGID
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getLayerAttribs
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getStoringCharacters
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] getProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] CCTMXMapInfo
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] formatWithTMXFile
-- @param  tmxFile

-----------------------
-- @function [parent=#CCTMXMapInfo] formatWithXML
-- @param  tmxString
-- @param  resourcePath

-----------------------
-- @function [parent=#CCTMXMapInfo] initWithTMXFile
-- @param  self
-- @param  tmxFile

-----------------------
-- @function [parent=#CCTMXMapInfo] initWithXML
-- @param  self
-- @param  tmxString
-- @param  resourcePath

-----------------------
-- @function [parent=#CCTMXMapInfo] parseXMLFile
-- @param  self
-- @param  xmlFilename

-----------------------
-- @function [parent=#CCTMXMapInfo] parseXMLString
-- @param  self
-- @param  xmlString

-----------------------
-- @function [parent=#CCTMXMapInfo] getTileProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] setTileProperties
-- @param  self
-- @param  tileProperties

-----------------------
-- @function [parent=#CCTMXMapInfo] getCurrentString
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] setCurrentString
-- @param  self
-- @param  currentString

-----------------------
-- @function [parent=#CCTMXMapInfo] getTMXFileName
-- @param  self

-----------------------
-- @function [parent=#CCTMXMapInfo] setTMXFileName
-- @param  self
-- @param  fileName

-----------------------
return nil
