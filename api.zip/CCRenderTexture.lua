-- @module CCRenderTexture

-----------------------
-- @function [parent=#CCRenderTexture] format
-- @param  self
-- @param  valid

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h
-- @param  eFormat
-- @param  uDepthStencilFormat

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h
-- @param  eFormat

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCRenderTexture] begin
-- @param  self

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  self
-- @param  r
-- @param  g
-- @param  b
-- @param  a
-- @param  depthValue
-- @param  stencilValue

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  self
-- @param  r
-- @param  g
-- @param  b
-- @param  a
-- @param  depthValue

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  self
-- @param  r
-- @param  g
-- @param  b
-- @param  a

-----------------------
-- @function [parent=#CCRenderTexture] endToLua
-- @param  self

-----------------------
-- @function [parent=#CCRenderTexture] clear
-- @param  self
-- @param  r
-- @param  g
-- @param  b
-- @param  a

-----------------------
-- @function [parent=#CCRenderTexture] clearDepth
-- @param  self
-- @param  depthValue

-----------------------
-- @function [parent=#CCRenderTexture] clearStencil
-- @param  self
-- @param  stencilValue

-----------------------
return nil
