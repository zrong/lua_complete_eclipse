-- @module CCTransitionMoveInL

-----------------------
-- @function [parent=#CCTransitionMoveInL] create
-- @param  t
-- @param  scene

-----------------------
return nil
