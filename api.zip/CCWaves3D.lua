-- @module CCWaves3D

-----------------------
-- @function [parent=#CCWaves3D] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude

-----------------------
return nil
