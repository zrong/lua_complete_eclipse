-- @module CCReverseTime

-----------------------
-- @function [parent=#CCReverseTime] create
-- @param  pAction

-----------------------
return nil
