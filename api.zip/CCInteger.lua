-- @module CCInteger

-----------------------
-- @function [parent=#CCInteger] CCInteger
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCInteger] getValue
-- @param  self

-----------------------
-- @function [parent=#CCInteger] create
-- @param  v

-----------------------
return nil
