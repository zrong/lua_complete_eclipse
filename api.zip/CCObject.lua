-- @module CCObject

-----------------------
-- @function [parent=#CCObject] release
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] retain
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] autorelease
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] copy
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] isSingleReference
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] retainCount
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] update
-- @param  self
-- @param  dt

-----------------------
return nil
