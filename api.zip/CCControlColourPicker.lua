-- @module CCControlColourPicker

-----------------------
-- @function [parent=#CCControlColourPicker] setColor
-- @param  self
-- @param  colorValue

-----------------------
-- @function [parent=#CCControlColourPicker] create

-----------------------
return nil
