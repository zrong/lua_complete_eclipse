-- @module cocos2dx

-----------------------
return nil
