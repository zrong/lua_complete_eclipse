-- @module CCSize

-----------------------
-- @function [parent=#CCSize] CCSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCSize] CCSize
-- @param  self
-- @param  other

-----------------------
-- @function [parent=#CCSize] CCSize
-- @param  self
-- @param  point

-----------------------
-- @function [parent=#CCSize] CCSize
-- @param  self

-----------------------
-- @function [parent=#CCSize] setSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCSize] equals
-- @param  self
-- @param  target

-----------------------
return nil
