-- @module LayoutProtocol

-----------------------
-- @function [parent=#LayoutProtocol] ctor
-- @param  self

-----------------------
-- @function [parent=#LayoutProtocol] setLayoutSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#LayoutProtocol] setLayout
-- @param  self
-- @param  layout

-----------------------
-- @function [parent=#LayoutProtocol] getLayout
-- @param  self

-----------------------
-- @function [parent=#LayoutProtocol] exportMethods
-- @param  self

-----------------------
return nil
