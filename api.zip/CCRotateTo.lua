-- @module CCRotateTo

-----------------------
-- @function [parent=#CCRotateTo] create
-- @param  fDuration
-- @param  fDeltaAngleX
-- @param  fDeltaAngleY

-----------------------
-- @function [parent=#CCRotateTo] create
-- @param  fDuration
-- @param  fDeltaAngle

-----------------------
return nil
