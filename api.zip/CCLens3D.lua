-- @module CCLens3D

-----------------------
-- @function [parent=#CCLens3D] create
-- @param  duration
-- @param  gridSize
-- @param  position
-- @param  radius

-----------------------
return nil
