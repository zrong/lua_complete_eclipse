-- @module Event

-----------------------
-- @field [parent=#Event] ENTER_SCENE

-----------------------
-- @field [parent=#Event] EXIT_SCENE

-----------------------
-- @field [parent=#Event] ENTER_TRANSITION_DID_FINISH

-----------------------
-- @field [parent=#Event] EXIT_TRANSITION_DID_START

-----------------------
-- @field [parent=#Event] CLEANUP

-----------------------
-- @field [parent=#Event] ENTER_FRAME

-----------------------
return nil
