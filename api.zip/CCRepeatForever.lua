-- @module CCRepeatForever

-----------------------
-- @function [parent=#CCRepeatForever] create
-- @param  pAction

-----------------------
return nil
