-- @module CCLabelTTF

-----------------------
-- @function [parent=#CCLabelTTF] setString
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCLabelTTF] getString
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelTTF] getHorizontalAlignment
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setHorizontalAlignment
-- @param  self
-- @param  alignment

-----------------------
-- @function [parent=#CCLabelTTF] getVerticalAlignment
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setVerticalAlignment
-- @param  self
-- @param  verticalAlignment

-----------------------
-- @function [parent=#CCLabelTTF] getDimensions
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setDimensions
-- @param  self
-- @param  dim

-----------------------
-- @function [parent=#CCLabelTTF] getFontSize
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setFontSize
-- @param  self
-- @param  fontSize

-----------------------
-- @function [parent=#CCLabelTTF] getFontName
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setFontName
-- @param  self
-- @param  fontName

-----------------------
-- @function [parent=#CCLabelTTF] create
-- @param  str
-- @param  fontName
-- @param  fontSize
-- @param  dimensions
-- @param  hAlignment
-- @param  vAlignment

-----------------------
-- @function [parent=#CCLabelTTF] create
-- @param  str
-- @param  fontName
-- @param  fontSize
-- @param  dimensions
-- @param  hAlignment

-----------------------
-- @function [parent=#CCLabelTTF] create
-- @param  str
-- @param  fontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCLabelTTF] create

-----------------------
return nil
