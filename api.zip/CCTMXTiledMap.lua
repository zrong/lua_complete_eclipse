-- @module CCTMXTiledMap

-----------------------
-- @function [parent=#CCTMXTiledMap] setMapSize
-- @param  self
-- @param  sz

-----------------------
-- @function [parent=#CCTMXTiledMap] getMapSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] setTileSize
-- @param  self
-- @param  sz

-----------------------
-- @function [parent=#CCTMXTiledMap] getTileSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] setMapOrientation
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCTMXTiledMap] getMapOrientation
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] setObjectGroups
-- @param  self
-- @param  pval

-----------------------
-- @function [parent=#CCTMXTiledMap] getObjectGroups
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] setProperties
-- @param  self
-- @param  pval

-----------------------
-- @function [parent=#CCTMXTiledMap] getProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] layerNamed
-- @param  self
-- @param  layerName

-----------------------
-- @function [parent=#CCTMXTiledMap] objectGroupNamed
-- @param  self
-- @param  groupName

-----------------------
-- @function [parent=#CCTMXTiledMap] create
-- @param  tmxFile

-----------------------
-- @function [parent=#CCTMXTiledMap] createWithXML
-- @param  tmxString
-- @param  resourcePath

-----------------------
return nil
