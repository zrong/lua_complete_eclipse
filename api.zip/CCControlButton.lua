-- @module CCControlButton

-----------------------
-- @function [parent=#CCControlButton] getCurrentTitle
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] getCurrentTitleColor
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] doesAdjustBackgroundImage
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] setAdjustBackgroundImage
-- @param  self
-- @param  adjustBackgroundImage

-----------------------
-- @function [parent=#CCControlButton] getTitleLabel
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] getBackgroundSprite
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] getPreferredSize
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] setPreferredSize
-- @param  self
-- @param  s

-----------------------
-- @function [parent=#CCControlButton] getZoomOnTouchDown
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] getLabelAnchorPoint
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] isPushed
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] getVerticalMargin
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] getHorizontalOrigin
-- @param  self

-----------------------
-- @function [parent=#CCControlButton] setMargins
-- @param  self
-- @param  marginH
-- @param  marginV

-----------------------
-- @function [parent=#CCControlButton] create
-- @param  title
-- @param  fontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCControlButton] create
-- @param  label
-- @param  backgroundSprite

-----------------------
-- @function [parent=#CCControlButton] create
-- @param  sprite

-----------------------
-- @function [parent=#CCControlButton] create

-----------------------
-- @function [parent=#CCControlButton] getTitleForState
-- @param  self
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleForState
-- @param  self
-- @param  title
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleColorForState
-- @param  self
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleColorForState
-- @param  self
-- @param  color
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleLabelForState
-- @param  self
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleLabelForState
-- @param  self
-- @param  label
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleTTFForState
-- @param  self
-- @param  fntFile
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleTTFForState
-- @param  self
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleTTFSizeForState
-- @param  self
-- @param  size
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleTTFSizeForState
-- @param  self
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleBMFontForState
-- @param  self
-- @param  fntFile
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleBMFontForState
-- @param  self
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getBackgroundSpriteForState
-- @param  self
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setBackgroundSpriteForState
-- @param  self
-- @param  sprite
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setBackgroundSpriteFrameForState
-- @param  self
-- @param  spriteFrame
-- @param  state

-----------------------
return nil
